<?php
include 'funcions.php';
mostrarMenu();
?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROJECTE VIDEOJOCS</title> 
</head>
</html>
